document.addEventListener('DOMContentLoaded', function() {
    const wrapper = document.querySelector('.wrapper');
    const registerLink = document.querySelector('.register-link');
    const loginLink = document.querySelector('.login-link');
    const loginForm = document.querySelector('.login-form');
    const registerForm = document.querySelector('#registerForm');

    // Handle form animations and transitions
    if (registerLink) {
        registerLink.addEventListener('click', (e) => {
            e.preventDefault();
            wrapper.classList.add('active');
        });
    }

    if (loginLink) {
        loginLink.addEventListener('click', (e) => {
            e.preventDefault();
            wrapper.classList.remove('active');
        });
    }

    // Handle login form submission
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const emailInput = this.querySelector('input[name="email"]');
            const passwordInput = this.querySelector('input[name="password"]');
            
            if (!emailInput.value || !passwordInput.value) {
                e.preventDefault();
                return;
            }
        });
    }

    // Handle registration steps
    const steps = document.querySelectorAll('.register-step');
    const nextButtons = document.querySelectorAll('.step-next');
    const prevButtons = document.querySelectorAll('.step-prev');
    
    let currentStep = 0;

    if (nextButtons.length > 0) {
        nextButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                if (currentStep < steps.length - 1) {
                    steps[currentStep].classList.remove('active');
                    currentStep++;
                    steps[currentStep].classList.add('active');
                }
            });
        });
    }

    if (prevButtons.length > 0) {
        prevButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                if (currentStep > 0) {
                    steps[currentStep].classList.remove('active');
                    currentStep--;
                    steps[currentStep].classList.add('active');
                }
            });
        });
    }
});

const translations = {
    pt: {
        footer: 'Plataforma que conecta pessoas e permite indicações com reconhecimento.',
        brand: 'O Saúde em Movimento (Conny) é mais do que um app, é um convite.\nCriado para quem quer começar, recomeçar ou simplesmente se sentir bem, o aplicativo conecta pessoas a atividades físicas, eventos esportivos e experiências reais.',
        loginTitle: 'Entrar',
        loginUserLabel: 'Usuário',
        loginPassLabel: 'Senha',
        loginButton: 'Entrar',
        loginLinkText: 'Não tem uma conta? <a href="#" class="register-link">Cadastre-se</a>',
        registerTitle: 'Cadastre-se',
        registerUserLabel: 'Usuário',
        registerEmailLabel: 'E-mail',
        registerPassLabel: 'Senha',
        registerButton: 'Cadastrar',
        registerLinkText: 'Já tem uma conta? <a href="#" class="login-link">Entrar</a>',
        infoLoginTitle: 'Bem-vindo de volta!',
        infoLoginDesc: 'Insira seus dados cadastrados para acessar o programa.',
        infoRegisterTitle: 'Bem-vindo!',
        infoRegisterDesc: 'Insira seus dados para criar uma nova conta.'
    },
    en: {
        footer: 'Platform that connects people and enables referrals with recognition.',
        brand: 'Saúde em Movimento (Conny) is more than an app, it is an invitation.\nCreated for those who want to start, restart, or simply feel good, the application connects people to physical activities, sports events, and real experiences.',
        loginTitle: 'Login',
        loginUserLabel: 'Username',
        loginPassLabel: 'Password',
        loginButton: 'Login',
        loginLinkText: 'Don\'t have an account? <a href="#" class="register-link">Sign up</a>',
        registerTitle: 'Sign up',
        registerUserLabel: 'Username',
        registerEmailLabel: 'Email',
        registerPassLabel: 'Password',
        registerButton: 'Sign up',
        registerLinkText: 'Already have an account? <a href="#" class="login-link">Login</a>',
        infoLoginTitle: 'Welcome back!',
        infoLoginDesc: 'Enter your registered details to access the program.',
        infoRegisterTitle: 'Welcome!',
        infoRegisterDesc: 'Enter your details to create a new account.'
    },
    jp: {
        footer: '人々をつなぎ、推薦による報酬を可能にするプラットフォーム。',
        brand: 'Saúde em Movimento（Conny）は単なるアプリではなく、招待状です。\n始めたい方、再スタートしたい方、ただ気分を良くしたい方のために作られたこのアプリは、人々をフィットネス、スポーツイベント、リアルな体験へとつなげます。',
        loginTitle: 'ログイン',
        loginUserLabel: 'ユーザー名',
        loginPassLabel: 'パスワード',
        loginButton: 'ログイン',
        loginLinkText: 'アカウントをお持ちでないですか？ <a href="#" class="register-link">サインアップ</a>',
        registerTitle: 'サインアップ',
        registerUserLabel: 'ユーザー名',
        registerEmailLabel: 'メール',
        registerPassLabel: 'パスワード',
        registerButton: 'サインアップ',
        registerLinkText: 'すでにアカウントをお持ちですか？ <a href="#" class="login-link">ログイン</a>',
        infoLoginTitle: 'お帰りなさい！',
        infoLoginDesc: '登録済みの詳細を入力してプログラムにアクセスしてください。',
        infoRegisterTitle: 'ようこそ！',
        infoRegisterDesc: '新しいアカウントを作成するための詳細を入力してください。'
    },
    kr: {
        footer: '사람들을 연결하고 추천으로 보상을 얻을 수 있는 플랫폼입니다.',
        brand: 'Saúde em Movimento(Conny)는 단순한 앱이 아니라 초대입니다.\n시작하고 싶거나, 다시 시작하고 싶거나, 단순히 기분이 좋아지고 싶은 사람들을 위해 만들어진 이 앱은 사람들을 신체 활동, 스포츠 이벤트 및 실제 경험에 연결합니다.',
        loginTitle: '로그인',
        loginUserLabel: '사용자 이름',
        loginPassLabel: '비밀번호',
        loginButton: '로그인',
        loginLinkText: '계정이 없으신가요? <a href="#" class="register-link">가입하기</a>',
        registerTitle: '가입하기',
        registerUserLabel: '사용자 이름',
        registerEmailLabel: '이메일',
        registerPassLabel: '비밀번호',
        registerButton: '가입하기',
        registerLinkText: '이미 계정이 있으신가요? <a href="#" class="login-link">로그인</a>',
        infoLoginTitle: '다시 오신 것을 환영합니다!',
        infoLoginDesc: '등록된 세부 정보를 입력하여 프로그램에 액세스하세요.',
        infoRegisterTitle: '환영합니다!',
        infoRegisterDesc: '새 계정을 만들기 위한 세부 정보를 입력하세요.'
    }
}

const reassignLinkEvents = () => {
    const registerLink = document.querySelector('.register-link');
    const loginLink = document.querySelector('.login-link');

    registerLink.onclick = () => {
        wrapper.classList.add('active');
    };

    loginLink.onclick = () => {
        wrapper.classList.remove('active');
    };
};

if (langSelect && footerDesc && brandText) {
    langSelect.addEventListener('change', (e) => {
        const v = e.target.value;
        const t = translations[v] || translations.pt;
        footerDesc.textContent = t.footer;
        brandText.textContent = t.brand;
        wrapperTexts.loginTitle.textContent = t.loginTitle;
        wrapperTexts.loginUserLabel.textContent = t.loginUserLabel;
        wrapperTexts.loginPassLabel.textContent = t.loginPassLabel;
        wrapperTexts.loginButton.textContent = t.loginButton;
        wrapperTexts.loginLinkText.innerHTML = t.loginLinkText;
        wrapperTexts.registerTitle.textContent = t.registerTitle;
        wrapperTexts.registerUserLabel.textContent = t.registerUserLabel;
        wrapperTexts.registerEmailLabel.textContent = t.registerEmailLabel;
        wrapperTexts.registerPassLabel.textContent = t.registerPassLabel;
        wrapperTexts.registerButton.textContent = t.registerButton;
        wrapperTexts.registerLinkText.innerHTML = t.registerLinkText;
        wrapperTexts.infoLoginTitle.textContent = t.infoLoginTitle;
        wrapperTexts.infoLoginDesc.textContent = t.infoLoginDesc;
        wrapperTexts.infoRegisterTitle.textContent = t.infoRegisterTitle;
        wrapperTexts.infoRegisterDesc.textContent = t.infoRegisterDesc;

        reassignLinkEvents();
    });
}

reassignLinkEvents();

const loginForm = document.querySelector('.form-box.login form');

if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault(); // Prevent default form submission

        const usernameInput = loginForm.querySelector('input[type="text"]');
        const passwordInput = loginForm.querySelector('input[type="password"]');

        if (usernameInput.value === 'teste' && passwordInput.value === 'teste') {
            window.location.href = '/pages/home/home.html'; // Redirect to correct home path
        } else {
            alert('Usuário ou senha incorretos!');
        }
    });
}

// --- Multi-step register form handling ---
const registerForm = document.querySelector('.form-box.register form#registerForm');
if (registerForm) {
    const steps = Array.from(registerForm.querySelectorAll('.register-step'));
    let current = 0;

    function showStep(i){
        steps.forEach((s, idx) => {
            if(idx === i) s.classList.add('active'); else s.classList.remove('active');
        });
    }

    // initial
    showStep(current);

    registerForm.addEventListener('click', (e) => {
        const t = e.target;
        if (t.closest('.step-next')) {
            e.preventDefault();
            // validate current step inputs
            const inputs = Array.from(steps[current].querySelectorAll('input'));
            const invalid = inputs.find(i => i.hasAttribute('required') && !i.value.trim());
            if (invalid) {
                invalid.focus();
                alert('Por favor preencha o campo: ' + (invalid.placeholder || invalid.name));
                return;
            }
            if (current < steps.length - 1) {
                current += 1;
                showStep(current);
            }
        }
        if (t.closest('.step-prev')) {
            e.preventDefault();
            if (current > 0) {
                current -= 1;
                showStep(current);
            }
        }
    });

    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // final validation: check all required and password match
        const formData = new FormData(registerForm);
        const name = formData.get('name')?.trim();
        const phone = formData.get('phone')?.trim();
        const email = formData.get('email')?.trim();
        const password = formData.get('password') || '';
        const password_confirm = formData.get('password_confirm') || '';

        if (!name || !phone || !email || !password || !password_confirm) {
            alert('Preencha todos os campos obrigatórios.');
            return;
        }
        if (password !== password_confirm) {
            alert('As senhas não conferem.');
            return;
        }

        // No back-end here: por ora apenas simula sucesso e redireciona para home
        // Você pode integrar envio via fetch para o backend conforme desejar.
        alert('Cadastro simulado concluído — implementar envio ao servidor.');
        // Exemplo: window.location.href = '/pages/home/home.html';
    });
}